document.addEventListener('DOMContentLoaded', function () {
    const darkModeCheckbox = document.getElementById('darkMode');
    const feature1Checkbox = document.getElementById('feature1');
    
    // Load saved settings from storage
    chrome.storage.sync.get(['darkMode', 'feature1'], function (data) {
        darkModeCheckbox.checked = data.darkMode || false;
        feature1Checkbox.checked = data.feature1 || false;
    });

    // Save settings
    document.getElementById('saveBtn').addEventListener('click', function () {
        chrome.storage.sync.set({
            darkMode: darkModeCheckbox.checked,
            feature1: feature1Checkbox.checked
        }, function () {
            alert('Settings saved!');
        });
    });
});
