// content.js
function openSettingsDialog() {
  const settingsDialogId = 'github-enhancer-settings-dialog';
  let settingsDialog = document.getElementById(settingsDialogId);
  if (settingsDialog) {
    settingsDialog.style.display = 'block';
    return;
  }

  settingsDialog = document.createElement('div');
  settingsDialog.id = settingsDialogId;
  settingsDialog.style.position = 'fixed';
  settingsDialog.style.top = '50%';
  settingsDialog.style.left = '50%';
  settingsDialog.style.transform = 'translate(-50%, -50%)';
  settingsDialog.style.backgroundColor = '#f6f8fa';
  settingsDialog.style.color = '#24292e';
  settingsDialog.style.padding = '20px';
  settingsDialog.style.border = '1px solid #d1d5da';
  settingsDialog.style.borderRadius = '6px';
  settingsDialog.style.zIndex = '1000';
  settingsDialog.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)';
  settingsDialog.style.display = 'block';
  settingsDialog.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"';
  settingsDialog.style.fontSize = '14px';

  const titleContainer = document.createElement('div');
  titleContainer.style.display = 'flex';
  titleContainer.style.justifyContent = 'space-between';
  titleContainer.style.alignItems = 'center';
  titleContainer.style.marginBottom = '15px';

  const title = document.createElement('h3');
  title.textContent = '⚙️ GitHub Enhancer Settings';
  title.style.fontWeight = '600';
  titleContainer.appendChild(title);

  const closeButton = document.createElement('button');
  closeButton.textContent = 'Close';
  closeButton.style.padding = '8px 15px';
  closeButton.style.marginLeft = '10px';
  closeButton.style.backgroundColor = '#f6f8fa';
  closeButton.style.color = '#24292e';
  closeButton.style.border = '1px solid #d1d5da';
  closeButton.style.borderRadius = '6px';
  closeButton.style.cursor = 'pointer';
  closeButton.addEventListener('click', function() {
    settingsDialog.style.display = 'none';
  });

  titleContainer.appendChild(closeButton);
  settingsDialog.appendChild(titleContainer);
  document.body.appendChild(settingsDialog);
}
