chrome.runtime.onInstalled.addListener(function () {
  console.log("GitHub Enhancer extension installed!");
});
