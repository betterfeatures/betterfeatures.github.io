document.getElementById('openSettingsBtn').addEventListener('click', function () {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') });
});
